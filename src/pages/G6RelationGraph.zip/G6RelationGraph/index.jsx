import React, { Component } from 'react';
import ChartSankey from './ChartSankey';

/**
 * 关系图示例页面
 */
class G6RelationGraphPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      graphData: [],
    };
  }

  componentDidMount() {
    this.loadData();
  }

  /**
   * 加载数据
   */
  loadData = () => {
    const rawData = {
      data: [
        {
          targetServiceUnitCode: 'BCAPZZ-SU-APP-ZYZC',
          sourceServiceUnitCode: 'BCAPZZ-SU-APP-OCCUP',
          sourceModuleKey: 'BCAPZZ',
          targetModuleKey: 'BCAPZZ',
          targetInterfaceName: 'notifyRefundResult',
        },
        {
          targetServiceUnitCode: 'BCAPZZ-SU-APP-XYBID',
          sourceServiceUnitCode: 'BCAPZZ-SU-APP-OCCUP',
          sourceModuleKey: 'BCAPZZ',
          targetModuleKey: 'BCAPZZ',
          targetInterfaceName: 'notifyRefundResult',
        },
      ],
    };

    // 转换为 G6 需要的 nodes/links 格式
    const nodeMap = new Map();
    const links = rawData.data.map((item) => {
      if (!nodeMap.has(item.sourceServiceUnitCode)) {
        nodeMap.set(item.sourceServiceUnitCode, { name: item.sourceServiceUnitCode });
      }
      if (!nodeMap.has(item.targetServiceUnitCode)) {
        nodeMap.set(item.targetServiceUnitCode, { name: item.targetServiceUnitCode });
      }
      return {
        source: item.sourceServiceUnitCode,
        target: item.targetServiceUnitCode,
        name: item.targetInterfaceName,
      };
    });

    this.setState({
      graphData: { nodes: Array.from(nodeMap.values()), links },
    });
  };

  

  /**
   * 节点点击事件
   */
  handleNodeClick = (nodeData) => {
    console.log('点击的节点数据：', nodeData);
  };

  /**
   * 边点击事件
   */
  handleEdgeClick = (edgeData) => {
    console.log('点击的边数据：', edgeData);
  };

  render() {
    const { graphData } = this.state;

    return (
      <div style={{ padding: 24, background: '#f0f2f5', minHeight: '100vh' }}>
        <div
          style={{
            background: '#fff',
            borderRadius: 8,
            padding: 24,
            marginBottom: 24,
          }}
        >
          <h2 style={{ margin: '0 0 16px 0', fontSize: 20, fontWeight: 600 }}>
            服务关系图
          </h2>
          <p style={{ margin: 0, color: '#8c8c8c', fontSize: 14 }}>
            展示服务单元之间的调用关系，支持拖拽、缩放、点击查看详情等功能。
          </p>
        </div>

        <div
          style={{
            background: '#fff',
            borderRadius: 8,
            padding: 24,
            minHeight: 600,
          }}
        >
          <ChartSankey
            data={graphData}
            width={1200}
            height={600}
            onNodeClick={this.handleNodeClick}
            onEdgeClick={this.handleEdgeClick}
          />
        </div>
      </div>
    );
  }
}

export default G6RelationGraphPage;
