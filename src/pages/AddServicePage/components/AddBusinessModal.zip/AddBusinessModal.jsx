import React, { Component } from 'react';
import { Modal, Form, Input, Button, message } from 'antd';

const { Item: FormItem } = Form;

/**
 * 新增业务链路弹窗组件
 */
class AddBusinessModal extends Component {
  constructor(props) {
    super(props);
    this.formRef = React.createRef();
  }

  /**
   * 关闭弹窗
   */
  handleCancel = () => {
    const { onCancel } = this.props;
    if (this.formRef.current) {
      this.formRef.current.resetFields();
    }
    if (typeof onCancel === 'function') {
      onCancel();
    }
  };

  /**
   * 提交表单
   */
  handleSubmit = () => {
    const { onSubmit } = this.props;
    if (this.formRef.current) {
      this.formRef.current.validateFields().then((values) => {
        console.log('用户填写的表单内容：', values);
        message.success('提交成功！');
        if (typeof onSubmit === 'function') {
          onSubmit(values);
        }
        // 重置表单
        this.formRef.current.resetFields();
      }).catch((error) => {
        console.error('表单验证失败：', error);
        message.error('请填写必填字段');
      });
    }
  };

  render() {
    const { visible } = this.props;

    return (
      <Modal
        title="新增业务链路"
        open={visible}
        onCancel={this.handleCancel}
        footer={null}
        width={600}
      >
        <Form ref={this.formRef} layout="vertical">
          <FormItem
            name="businessType"
            label="业务类别"
            rules={[{ required: true, message: '请输入业务类别' }]}
          >
            <Input placeholder="请输入业务类别" />
          </FormItem>
          <FormItem
            name="businessName"
            label="业务名称"
            rules={[{ required: true, message: '请输入业务名称' }]}
          >
            <Input placeholder="请输入业务名称" />
          </FormItem>
          <FormItem
            name="businessLinkName"
            label="业务链路名称"
            rules={[{ required: true, message: '请输入业务链路名称' }]}
          >
            <Input placeholder="请输入业务链路名称" />
          </FormItem>
          <FormItem
            name="targetSys"
            label="系统名称"
            rules={[{ required: true, message: '请输入系统名称' }]}
          >
            <Input placeholder="请输入系统名称" />
          </FormItem>
          <FormItem
            name="targetModule"
            label="模块名称"
          >
            <Input placeholder="请输入模块名称" />
          </FormItem>
          <FormItem
            name="targetServiceUnit"
            label="服务单元名称"
          >
            <Input placeholder="请输入服务单元名称" />
          </FormItem>
          <FormItem
            name="callServiceName"
            label="调用名称"
          >
            <Input placeholder="请输入调用名称" />
          </FormItem>
          <FormItem
            name="opUser"
            label="操作人"
            rules={[{ required: true, message: '请输入操作人' }]}
          >
            <Input placeholder="请输入操作人" />
          </FormItem>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 12, marginTop: 24 }}>
            <Button onClick={this.handleCancel}>取消</Button>
            <Button type="primary" onClick={this.handleSubmit}>
              提交
            </Button>
          </div>
        </Form>
      </Modal>
    );
  }
}

export default AddBusinessModal;