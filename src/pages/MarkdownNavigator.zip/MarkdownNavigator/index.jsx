import React, { useEffect, useState } from 'react';
import { markdown } from 'markdown';

// 使用 Vite 的 glob 导入，匹配 ./data/ 下所有 .md 文件
// 返回一个对象：键是文件路径，值是一个异步函数，调用后返回文件内容字符串
const mdModules = import.meta.glob('./data/*.md', { as: 'raw', eager: false });

const MarkdownNavigator = () => {
  const [fileList, setFileList] = useState([]);      // [{ title, name, path }]
  const [currentContent, setCurrentContent] = useState('');
  const [selectedPath, setSelectedPath] = useState('');
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // 组件挂载时：提取所有文件的标题，但不保存正文内容
  useEffect(() => {
    const extractTitles = async () => {
      const entries = Object.entries(mdModules);
      const list = [];

      for (const [path, importer] of entries) {
        // 调用异步函数获取文件完整内容
        const rawContent = await importer();
        // 提取第一行标题（格式：# 标题）
        const firstLine = rawContent.split(/\r?\n/)[0] || '';
        const match = firstLine.match(/^#\s*(.+)/);
        const title = match ? match[1].trim() : '无标题';
        const fileName = path.split('/').pop().replace(/\.md$/, '');
        list.push({ title, name: fileName, path });
      }
      setFileList(list);
      // 默认选中第一个文件并加载其内容
      if (list.length > 0) {
        handleSelect(list[0].path, list[0].title);
      }
    };
    extractTitles();
  }, []);

  // 点击标题时：真正动态加载对应 .md 文件的内容
  const handleSelect = async (path, title) => {
    // 如果已经是当前选中的文件，不做重复加载
    if (selectedPath === path) return;

    setSelectedPath(path);
    setLoading(true);
    try {
      const importer = mdModules[path];
      if (importer) {
        const content = await importer();
        setCurrentContent(content);
      } else {
        setCurrentContent('文件不存在或加载失败');
      }
    } catch (error) {
      console.error('加载 Markdown 文件失败：', error);
      setCurrentContent('加载出错');
    } finally {
      setLoading(false);
    }
  };

  // 搜索过滤后的列表
  const filteredList = fileList.filter((item) =>
    item.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div style={{
      display: 'flex',
      height: '100%',
      background: '#fff',
      borderRadius: 8,
    }}>
      {/* 左侧标题列表 */}
      <aside style={{
        width: 240,
        minWidth: 240,
        borderRight: '1px solid #f0f0f0',
        padding: '16px',
        overflowY: 'auto',
        background: '#fafafa',
      }}>
        <h3 style={{
          margin: '0 0 16px 0',
          fontSize: 14,
          fontWeight: 600,
          color: '#262626',
        }}>
          文档列表
        </h3>
        <div style={{ position: 'relative', marginBottom: 16 }}>
          <input
            type="text"
            placeholder="搜索文档标题..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{
              width: '100%',
              padding: '8px 30px 8px 12px',
              border: '1px solid #d9d9d9',
              borderRadius: 6,
              fontSize: 13,
              outline: 'none',
              boxSizing: 'border-box',
            }}
          />
          {searchTerm && (
            <span
              onClick={() => setSearchTerm('')}
              style={{
                position: 'absolute',
                right: 8,
                top: '50%',
                transform: 'translateY(-50%)',
                cursor: 'pointer',
                color: '#999',
                fontSize: 14,
              }}
            >
              ×
            </span>
          )}
        </div>
        {filteredList.length === 0 ? (
          <div style={{ color: '#999', fontSize: 13 }}>
            {searchTerm ? '未找到匹配的文档' : '暂无文档'}
          </div>
        ) : (
          <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
            {filteredList.map((item) => (
              <li
                key={item.path}
                onClick={() => handleSelect(item.path, item.title)}
                style={{
                  cursor: 'pointer',
                  marginBottom: '8px',
                  fontWeight: selectedPath === item.path ? 'bold' : 'normal',
                  color: selectedPath === item.path ? '#1677ff' : '#333',
                  padding: '8px 12px',
                  borderRadius: 6,
                  background: selectedPath === item.path ? '#e6f4ff' : 'transparent',
                  transition: 'all 0.2s',
                  fontSize: 14,
                }}
                onMouseEnter={(e) => {
                  if (selectedPath !== item.path) {
                    e.currentTarget.style.background = '#f5f5f5';
                  }
                }}
                onMouseLeave={(e) => {
                  if (selectedPath !== item.path) {
                    e.currentTarget.style.background = 'transparent';
                  }
                }}
              >
                {item.title}
              </li>
            ))}
          </ul>
        )}
      </aside>

      {/* 右侧 Markdown 渲染区域 */}
      <main style={{
        flex: 1,
        padding: '24px 32px',
        overflowY: 'auto',
        maxWidth: 'calc(100% - 240px)',
      }}>
        {loading ? (
          <div style={{ textAlign: 'center', color: '#999', padding: 40 }}>
            加载中...
          </div>
        ) : currentContent ? (
          <div
            style={{ lineHeight: 1.8 }}
            dangerouslySetInnerHTML={{ __html: markdown.toHTML(currentContent) }}
          />
        ) : (
          <div style={{ textAlign: 'center', color: '#999', padding: 40 }}>
            请选择左侧文档查看内容
          </div>
        )}
      </main>
    </div>
  );
};

export default MarkdownNavigator;
